import { ref } from "vue";
import { defineStore } from "pinia";

export let  useAuthStore = defineStore("auth", () => {
  const data = ref(null);
  const OPT = ref(null)

  function setAuthData(e) {
    data.value = e
  }
  function clearAuthData() {
    data.value = null;
  }

  function setAuthOPT(e){OPT.value = e}

  return { data , OPT , setAuthData , clearAuthData , setAuthOPT };
});